import json
from google import genai
from google.genai import types
from config import GEMINI_API_KEY, LANGUAGE

client = genai.Client(api_key=GEMINI_API_KEY)

PROMPT = """
Create one original short YouTube video package.
Return ONLY valid JSON with:
{
  "topic": "...",
  "title": "...",
  "description": "...",
  "script": "...",
  "visual_queries": ["...", "...", "...", "...", "..."],
  "safety_notes": ["..."]
}

Requirements:
- Language: {language}
- Educational/interesting and advertiser-friendly.
- No copied article text.
- Original 40-60 second script.
- Visual queries must describe generic footage suitable for a licensed stock-video library.
""".format(language=LANGUAGE)

def make_package():
    response = client.models.generate_content(
        model="gemini-2.5-flash",
        contents=PROMPT,
        config=types.GenerateContentConfig(
            response_mime_type="application/json",
            temperature=0.7,
        ),
    )
    return json.loads(response.text)
