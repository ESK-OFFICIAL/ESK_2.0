import os
import subprocess
import requests
from pathlib import Path
from pexels import search_video, pick_file

ROOT = Path(os.getenv("WORK_DIR", "work"))
MEDIA = ROOT / "media"
MEDIA.mkdir(parents=True, exist_ok=True)

def download(url, path):
    with requests.get(url, stream=True, timeout=60) as r:
        r.raise_for_status()
        with open(path, "wb") as f:
            for chunk in r.iter_content(1024 * 128):
                if chunk:
                    f.write(chunk)

def make_video(package):
    clips = []
    for i, query in enumerate(package["visual_queries"]):
        videos = search_video(query)
        if not videos:
            continue
        path = MEDIA / f"clip_{i:02d}.mp4"
        download(pick_file(videos[0]), path)
        clips.append(path)

    if not clips:
        raise RuntimeError("No stock clips were found.")

    normalized = []
    for i, path in enumerate(clips):
        out = MEDIA / f"norm_{i:02d}.mp4"
        subprocess.run([
            "ffmpeg", "-y", "-i", str(path),
            "-vf", "scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920",
            "-t", "9", "-an", "-r", "30", str(out)
        ], check=True)
        normalized.append(out)

    concat = ROOT / "concat.txt"
    concat.write_text(
        "\n".join(f"file '{p.resolve()}'" for p in normalized),
        encoding="utf-8"
    )

    raw = ROOT / "visual.mp4"
    subprocess.run([
        "ffmpeg", "-y", "-f", "concat", "-safe", "0",
        "-i", str(concat), "-c", "copy", str(raw)
    ], check=True)
    return raw
