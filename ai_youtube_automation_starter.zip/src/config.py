import os

GEMINI_API_KEY = os.environ["GEMINI_API_KEY"]
PEXELS_API_KEY = os.environ["PEXELS_API_KEY"]
LANGUAGE = os.getenv("CHANNEL_LANGUAGE", "en")
