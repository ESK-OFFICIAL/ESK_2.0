import json
import subprocess
from pathlib import Path
from gemini import make_package
from build_video import make_video

def main():
    Path("work").mkdir(exist_ok=True)
    package = make_package()
    Path("work/package.json").write_text(
        json.dumps(package, indent=2, ensure_ascii=False),
        encoding="utf-8"
    )
    visual = make_video(package)
    Path("output").mkdir(exist_ok=True)
    # First build intentionally stops at a verified visual master.
    subprocess.run([
        "ffmpeg", "-y", "-i", str(visual),
        "-c:v", "libx264", "-pix_fmt", "yuv420p",
        "-an", "output/final.mp4"
    ], check=True)
    print("Created output/final.mp4")

if __name__ == "__main__":
    main()
