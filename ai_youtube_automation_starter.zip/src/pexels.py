import requests
from config import PEXELS_API_KEY

def search_video(query, per_page=5):
    r = requests.get(
        "https://api.pexels.com/videos/search",
        headers={"Authorization": PEXELS_API_KEY},
        params={"query": query, "per_page": per_page, "orientation": "portrait"},
        timeout=30,
    )
    r.raise_for_status()
    return r.json().get("videos", [])

def pick_file(video):
    files = video.get("video_files", [])
    if not files:
        raise RuntimeError("Pexels returned a video without a downloadable file.")
    usable = [x for x in files if x.get("width", 0) >= 720]
    return max(usable or files, key=lambda x: x.get("width", 0) * x.get("height", 0))["link"]
