# AI YouTube Automation — Free/No-PC Starter

This repository is designed to run from GitHub Actions, so no local PC is required.

## Pipeline
Schedule/manual trigger -> Gemini topic + script -> Piper TTS -> Pexels licensed stock video -> FFmpeg assembly -> YouTube upload.

## Important
- Keep the repository PRIVATE.
- Never put API keys or OAuth tokens in source files.
- This does NOT promise unlimited free cloud compute or unlimited API usage.
- The initial visual pipeline uses licensed stock footage. It is not the same as AI-generated video.
- Review YouTube policies and every media source's license before publishing.

## GitHub Secrets
GEMINI_API_KEY
PEXELS_API_KEY
YOUTUBE_CLIENT_ID
YOUTUBE_CLIENT_SECRET
YOUTUBE_REFRESH_TOKEN

## First run
1. Create a PRIVATE GitHub repository.
2. Upload this project.
3. Add secrets under Settings -> Secrets and variables -> Actions.
4. Run Actions -> AI YouTube Automation manually.
5. Keep upload=false for the first test.
